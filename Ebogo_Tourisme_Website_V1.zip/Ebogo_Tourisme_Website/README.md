# Ebogo Tourisme — Site web bilingue

Première version du site touristique d'Ebogo, en français et en anglais.

## Contenu inclus

- Page d'accueil immersive
- Présentation de la destination
- Activités touristiques
- Offres rapides
- Grille tarifaire détaillée
- Galerie d'images
- Formulaire de réservation WhatsApp
- Contact WhatsApp et email
- Version bilingue FR / EN

## Tester dans Codespaces

1. Dézipper le fichier.
2. Entrer dans le dossier :

```bash
cd Ebogo_Tourisme_Website
```

3. Lancer un serveur local simple :

```bash
python3 -m http.server 5173
```

4. Dans l'onglet `Ports`, ouvrir le port `5173`.

## Déployer

Ce site est statique. Il peut être déployé sur :

- GitHub Pages
- Netlify
- Vercel
- n'importe quel hébergement web classique

## Contact intégré

WhatsApp : +237 677 37 96 97
Email : sitetouristiquedebogo1@gmail.com

## Note

Les tarifs affichés sont indicatifs et doivent être confirmés par WhatsApp avant la visite.
